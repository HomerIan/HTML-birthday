$(window).load(function(){
	$('.loading').fadeOut('fast');
	$('.container').fadeIn('fast');
});
$('document').ready(function(){
		var vw;
		$(window).resize(function(){
			 vw = $(window).width()/2;
			$('#b1,#b2,#b3,#b4,#b5').stop();
			$('#b11').animate({top:240, left: vw-350},500);
			$('#b22').animate({top:240, left: vw-250},500);
			$('#b33').animate({top:240, left: vw-150},500);
			$('#b44').animate({top:240, left: vw-50},500);
			$('#b55').animate({top:240, left: vw+50},500);
		});

	$('#turn_on').click(function(){
		$('#bulb_yellow').addClass('bulb-glow-yellow');
		$('#bulb_red').addClass('bulb-glow-red');
		$('#bulb_blue').addClass('bulb-glow-blue');
		$('#bulb_green').addClass('bulb-glow-green');
		$('#bulb_pink').addClass('bulb-glow-pink');
		$('#bulb_orange').addClass('bulb-glow-orange');
		$('#bulb_yellow1').addClass('bulb-glow-yellow1');
		$('#bulb_red1').addClass('bulb-glow-red1');
		$('#bulb_blue1').addClass('bulb-glow-blue1');
		$('#bulb_green1').addClass('bulb-glow-green1');
		$('#bulb_pink1').addClass('bulb-glow-pink1');
		$('#bulb_orange1').addClass('bulb-glow-orange1');
		$('body').addClass('pink');
		$(this).fadeOut('slow').delay(5000).promise().done(function(){
			$('#play').fadeIn('slow');
		});
	});
	$('#play').click(function(){
		var audio = $('.song')[0];
        audio.play();
        $('#bulb_yellow').addClass('bulb-glow-yellow-after');
		$('#bulb_red').addClass('bulb-glow-red-after');
		$('#bulb_blue').addClass('bulb-glow-blue-after');
		$('#bulb_green').addClass('bulb-glow-green-after');
		$('#bulb_pink').addClass('bulb-glow-pink-after');
		$('#bulb_orange').addClass('bulb-glow-orange-after');
		$('#bulb_yellow1').addClass('bulb-glow-yellow-after1');
		$('#bulb_red1').addClass('bulb-glow-red-after1');
		$('#bulb_blue1').addClass('bulb-glow-blue-after1');
		$('#bulb_green1').addClass('bulb-glow-green-after1');
		$('#bulb_pink1').addClass('bulb-glow-pink-after1');
		$('#bulb_orange1').addClass('bulb-glow-orange-after1');
		$('body').css('backgroud-color','#FFF');
		$('body').addClass('pink_after');
		$(this).fadeOut('slow').delay(10000).promise().done(function(){
			$('#banner_teddybear_coming').fadeIn('slow');
		});
	});

	$('#banner_teddybear_coming').click(function(){
		$('.banner').addClass('banner-come');
		$('.teddybear').fadeIn('slow');
		$('.teddybear').addClass('teddybear-show');
		$('.balloon-border').animate({top:-10},6000);
		$('#b1,#b3,#b5').addClass('balloons-rotate-behaviour-one');
		$('#b2,#b4').addClass('balloons-rotate-behaviour-two');
		loopOne();
		loopTwo();
		loopThree();
		loopFour();
		loopFive();
		$(this).fadeOut('slow').delay(12000).promise().done(function(){
			$('#story').fadeIn('slow');
		});
	});

	function loopOne() {
		var randleft = 1000*Math.random();
		var randtop = 600*Math.random();
		$('#b1').animate({left:randleft,bottom:randtop},10000,function(){
			loopOne();
		});
	}
	function loopTwo() {
		var randleft = 1000*Math.random();
		var randtop = 600*Math.random();
		$('#b2').animate({left:randleft,bottom:randtop},10000,function(){
			loopTwo();
		});
	}
	function loopThree() {
		var randleft = 1000*Math.random();
		var randtop = 600*Math.random();
		$('#b3').animate({left:randleft,bottom:randtop},10000,function(){
			loopThree();
		});
	}
	function loopFour() {
		var randleft = 1000*Math.random();
		var randtop = 600*Math.random();
		$('#b4').animate({left:randleft,bottom:randtop},10000,function(){
			loopFour();
		});
	}
	function loopFive() {
		var randleft = 1000*Math.random();
		var randtop = 600*Math.random();
		$('#b5').animate({left:randleft,bottom:randtop},10000,function(){
			loopFive();
		});
	}
	
	$('#story').click(function(){
		$(this).fadeOut('slow');
		$('.cake').fadeOut('fast').promise().done(function(){
			$('.message').fadeIn('slow');
		});
		
		var i;

		function msgLoop (i) {
			$("p:nth-child("+i+")").fadeOut('slow').delay(1000).promise().done(function(){
			i=i+1;
			$("p:nth-child("+i+")").fadeIn('slow').delay(1000);
			if(i==47){
				$("p:nth-child(46)").fadeOut('slow').delay(4000).promise().done(function () {
					$('#wish_message').fadeIn('slow');
				});
				
			}
			else{
				msgLoop(i);
			}			

		});
		}
		
		msgLoop(0);
		
	});

	$('#wish_message').click(function(){
	 $('.song')[0].pause();
		var audio = $('.bdaysong')[0];
        audio.play();
		 vw = $(window).width()/2;
		$('#b1,#b2,#b3,#b4,#b5,#b6,#b7').stop();
		$('#b1').attr('id','b11');
		$('#b2').attr('id','b22')
		$('#b3').attr('id','b33')
		$('#b4').attr('id','b44')
		$('#b5').attr('id','b55')
		$('#b11').animate({top:240, left: vw-350},500);
		$('#b22').animate({top:240, left: vw-250},500);
		$('#b33').animate({top:240, left: vw-150},500);
		$('#b44').animate({top:240, left: vw-50},500);
		$('#b55').animate({top:240, left: vw+50},500);
		$('.balloons').css('opacity','0.9');
		$('.balloons h2').fadeIn(3000);
		$(this).fadeOut('slow').delay(25000).promise().done(function(){
			$('#finale').fadeIn('slow');
		});
	});

	$('#finale').click(function(){
		$(this).fadeOut('slow');
		$('body').removeClass('pink');
		$('body').removeClass('pink_after');
		$('.teddybear').fadeOut('slow');
		$('.teddybear').removeClass('teddybear-show').fadeOut('slow');
		$('.banner').fadeOut('slow');
		$('.balloon-border').fadeOut('slow');
		$('#b1,#b3,#b5,#b11,#b33,#b55').fadeOut('slow');
		$('#b2,#b4,#b22,#b44').fadeOut('slow');
		$('#bulb_yellow').removeClass('bulb-glow-yellow-after').fadeOut('slow');
		$('#bulb_red').removeClass('bulb-glow-red-after').fadeOut('slow');
		$('#bulb_blue').removeClass('bulb-glow-blue-after').fadeOut('slow');
		$('#bulb_green').removeClass('bulb-glow-green-after').fadeOut('slow');
		$('#bulb_pink').removeClass('bulb-glow-pink-after').fadeOut('slow');
		$('#bulb_orange').removeClass('bulb-glow-orange-after').fadeOut('slow');
		$('#bulb_yellow1').removeClass('bulb-glow-yellow-after1').fadeOut('slow');
		$('#bulb_red1').removeClass('bulb-glow-red-after1').fadeOut('slow');
		$('#bulb_blue1').removeClass('bulb-glow-blue-after1').fadeOut('slow');
		$('#bulb_green1').removeClass('bulb-glow-green-after1').fadeOut('slow');
		$('#bulb_pink1').removeClass('bulb-glow-pink-after1').fadeOut('slow');
		$('#bulb_orange1').removeClass('bulb-glow-orange-after1').fadeOut('slow');
		var audio = $('.light')[0];
		audio.play();
		$('body').addClass('background').fadeIn('slow');
		$('#red-lantern1').delay(45000).animate({top:-500},28000);
		$('#yellow-lantern1').delay(47000).animate({top:-500},25000);
		$('#red-lantern2').delay(40000).animate({top:-500},30000);
		$('#yellow-lantern2').delay(40000).animate({top:-500},33000);
		$('#red-lantern3').delay(46000).animate({top:-500},37000);
		$('#yellow-lantern3').delay(44000).animate({top:-500},35000);
		$('#red-lantern4').delay(40000).animate({top:-500},30000);
		$('#yellow-lantern4').delay(48000).animate({top:-500},27000);
		$('#red-lantern5').delay(44000).animate({top:-500},31000);
		$('#yellow-lantern5').delay(41000).animate({top:-500},34000);
		$('#red-lantern6').delay(40000).animate({top:-500},45000);
		$('#yellow-lantern6').delay(42000).animate({top:-500},33000);
		$('#red-lantern7').delay(43000).animate({top:-500},37000);
		$('#yellow-lantern7').delay(42000).animate({top:-500},39000);
		$('#red-lantern8').delay(40000).animate({top:-500},41000);
		$('#yellow-lantern8').delay(43000).animate({top:-500},29000);
		$('#red-lantern9').delay(46000).animate({top:-500},36000);
		$('#yellow-lantern9').delay(41000).animate({top:-500},42000);
		$('#red-lantern10').delay(42000).animate({top:-500},48000);
		$('#yellow-lantern10').delay(46000).animate({top:-500},47000);
		$('#boat').delay(12000).animate({left:2000},300000);
		
		$('#red-lantern11').delay(135000).animate({top:-500},28000);
		$('#yellow-lantern11').delay(129000).animate({top:-500},29000);
		$('#red-lantern12').delay(130000).animate({top:-500},30000);
		$('#yellow-lantern12').delay(137000).animate({top:-500},33000);
		$('#red-lantern13').delay(133000).animate({top:-500},37000);
		$('#yellow-lantern13').delay(139000).animate({top:-500},35000);
		$('#red-lantern14').delay(151000).animate({top:-500},30000);
		$('#yellow-lantern14').delay(141000).animate({top:-500},27000);
		$('#red-lantern15').delay(130000).animate({top:-500},31000);
		$('#yellow-lantern15').delay(139000).animate({top:-500},34000);
		$('#red-lantern16').delay(129000).animate({top:-500},45000);
		$('#yellow-lantern16').delay(142000).animate({top:-500},33000);
		$('#red-lantern17').delay(140000).animate({top:-500},37000);
		$('#yellow-lantern17').delay(142000).animate({top:-500},39000);
		$('#red-lantern18').delay(132000).animate({top:-500},41000);
		$('#yellow-lantern18').delay(130000).animate({top:-500},29000);
		$('#red-lantern19').delay(133000).animate({top:-500},36000);
		$('#yellow-lantern19').delay(131000).animate({top:-500},42000);
		$('#red-lantern20').delay(144000).animate({top:-500},48000);
		$('#yellow-lantern20').delay(142000).animate({top:-500},47000);
	});
});
